"""Versioned engine boundaries. No inference, network or filesystem work on import."""
__version__ = '0.2.0rc1'
