"""Editable LI access scenario; no retrieval or routing runs on import.

Edit CONFIG here, then export a NEW snapshot for each analysis run:
    python notebooks/location_intelligent_config.py > /tmp/li-policy.json

This is a policy snapshot, NOT the li_routing_config_v1 consumed by the
historical N1 diagnostic engine. Integration requires a separately tested
policy-aware routing profile. None denotes an unresolved decision, except
an explicitly UNBOUNDED limit, where it means no finite cap. Never zero.
"""
from copy import deepcopy
import json


CONFIG = {
    "schema_version": "li_access_policy_v1",
    "policy_version": "motorcycle_experiment_v8_li3",
    "status": "LI3_PILOT_SCENARIO_NOT_PRODUCTION_VALIDATED",
    "decision_basis": "Owner clarification: D02/D03/D05/D10, 2026-10-22",
    "travel": {
        "mode": "motorcycle",
        "direction": "building_to_store",
        "max_travel_min": {"value": 10.0, "unit": "min"},
        "threshold_status": "TEMPORARY_BUSINESS_SCENARIO_NOT_VALIDATED",
        "threshold_comparison": "<=",
        "threshold_rounding": "PYTHON_ROUND_HALF_EVEN_TOTAL_MINUTES_BEFORE_COMPARISON",
        "reference_constant_speed": {"value": 7.0, "unit": "km/h"},
        "speed_status": "N1_ASSUMPTION_NOT_VALIDATED_FOR_MOTORCYCLE",
        "segment_speed_model": "ALL_SEGMENTS_USE_REFERENCE_CONSTANT_SPEED",
    },
    "connectors": {
        "max_building_to_road_m": {"value": 125.0, "unit": "m"},
        "distance_status": "EXPERIMENTAL_CANDIDATE_SEARCH_LIMIT",
        "reference_search_origin": "BUILDING_REPRESENTATIVE_POINT",
        "distance_measure": "PROJECTED_POINT_TO_ROAD_GEOMETRY_DISTANCE",
        "candidate_distance_is_access_evidence": False,
        "building_access": "USE_EVIDENCE_OR_EXPLICIT_OWNER_ACCEPTED_ASSUMPTION",
        "store_entrance": "USE_EVIDENCE_OR_EXPLICIT_OWNER_ACCEPTED_ASSUMPTION",
        "require_access_evidence": True,
        "unknown_access_usable": False,
        "infer_straight_line_access": False,
        "max_target_snap_m": {"value": None, "unit": "m",
                              "limit_type": "UNBOUNDED"},
        "target_snap_search_scope": "AVAILABLE_GRAPH_ONLY",
        "target_snap_selection": "NEAREST_VALID_ROAD",
        "candidate_selection": "HIGHEST_VALID_ACCESS_CLASS_THEN_MINIMUM_TOTAL_TIME",
        "candidate_comparison_precision": "FULL_PRECISION_BEFORE_THRESHOLD_ROUND",
        "entrance_location_policy": "ASSUME_ROAD_FACING_BUILDING_LOCATION_IS_ENTRANCE",
        "entrance_location_claim_type": "OWNER_ACCEPTED_ASSUMPTION_NOT_OBSERVATION",
        "road_facing_location_method": "FACE_HIGHEST_ROAD_CLASS",
        "road_class_hierarchy": [
            ["primary"],
            ["secondary"],
            ["tertiary"],
            ["unclassified", "residential", "living_street"],
            ["service"],
            ["track", "path"],
        ],
        "highest_class_vs_valid_access_precedence": "VALID_ACCESS_BEFORE_CLASS_RANK",
        "highest_class_vs_minimum_time_precedence": "CLASS_RANK_BEFORE_TOTAL_TIME",
        "unreachable_higher_class": "TRY_NEXT_REACHABLE_CLASS",
        "link_class_mapping": "USE_PARENT_CLASS",
        "entrance_assumption_overrides_access_restrictions": False,
        "entrance_candidate_distance_rule": None,
        "target_connector_cost_model": "CONNECTOR_DISTANCE_AT_REFERENCE_CONSTANT_SPEED",
    },
    "sources": {
        "target": {
            "provider": "EXPLICIT_TARGET_INPUT",
            "coordinate_source": None,
            "source_version_or_as_of": None,
        },
        "buildings": {
            "provider": "OVERTURE_MAPS",
            "planned_release": "2026-10-21.0",
            "planned_schema_version": "2.0.0",
            "status": "PLANNED_NOT_ACQUIRED_OR_ADAPTER_VALIDATED",
            "reference_n1_release": "2026-08-19.0",
        },
        "roads_access_barriers_turns": {
            "provider": "OPENSTREETMAP_VIA_OVERPASS",
            "library": "OSMNX",
            "planned_library_version": "2.1.1",
            "network_type": "drive_service",
            "network_filter_is_complete_motorcycle_profile": False,
            "overpass_endpoint": None,
            "server_version": None,
            "snapshot_as_of": None,
            "restriction_relation_acquisition": None,
            "status": "PLANNED_NOT_ACQUIRED_OR_ADAPTER_VALIDATED",
        },
        "provenance": {
            "record_raw_and_normalized_checksums": True,
            "record_extent_request_filter_versions_and_missing_reasons": True,
        },
    },
    "capacity_reference": {
        "profile": "N1_SPLIT_REFERENCE_ONLY",
        "standard_residential_value": 4,
        "estimate_level_from_height": True,
        "floor_height_m": 3.0,
        "apartment": {"net_ratio": 0.70, "average_area_m2": 45.0, "occupancy": 0.70},
        "dormitory": {"net_ratio": 0.70, "average_area_m2": 15.0, "occupancy": 0.75},
        "hotel": {"net_ratio": 0.65, "average_area_m2": 30.0, "occupancy": 0.45,
                  "guests_per_occupied_room": 2.0},
        "allow_mixed_unit_total": False,
    },
    "li3": {
        "pilot_location_source": "OWNER_APPROVED_N1_EXAMPLE",
        "longitude": 106.8101931806858,
        "latitude": -6.430669461543375,
        "metric_crs": "EPSG:32748",
        "network_bbox_radius_m": 5500.0,
        "building_cache": "results/location_intelligent/overture_20261021_n1_verified",
        "overpass_endpoints": ["https://overpass-api.de/api/interpreter",
                               "https://overpass.kumi.systems/api/interpreter"],
        "request_timeout_s": 45,
        "max_response_bytes": 67108864,
        "network_type": "drive_service",
        "motor_supplements": True,
        "unsupported_restrictions": "QUARANTINE_AFFECTED_MOVEMENTS_AND_REPORT_UNKNOWN",
        "source_node_topology_only": True,
        "projection_position_precision_m": 0.000001,
        "entrance_inset_m": 0.01,
        "connector_assumption": "OWNER_FRONTAGE_ASSUMPTION_WITH_MAPPED_BARRIER_CHECK",
        "live_physical_verification": False,
    },
    "motorcycle_access": {
        "verified_motorcycle_alley_usable": True,
        "mapped_alley_missing_motorcycle_permission": "ASSUME_USABLE_UNLESS_PROHIBITED",
        "pedestrian_only_usable": False,
        "stairs_usable": False,
        "private_access_usable": False,
        "unknown_access_usable": False,
        "gates_and_prohibitions": "GATE_ASSUMED_PASSABLE_UNLESS_CLOSED_OR_PROHIBITED",
        "respect_direction": True,
        "cross_unverified_barriers": False,
        "invent_u_turns_or_reverse_edges": False,
        "provider_tag_mapping": None,
        "turn_restriction_model": None,
        "park_and_walk_policy": "MOTORCYCLE_ONLY_NO_WALKING_LEG",
        "no_route_policy": "EXCLUDE_FROM_COUNT_WITH_REASON",
    },
    "evidence": {
        "unknown_access_status": "UNVERIFIED_EXCLUDED_FROM_ROUTING",
        "exclusion_is_proof_of_physical_inaccessibility": False,
        "owner_accepted_assumptions": [
            "MAPPED_ALLEY_USABLE_UNLESS_PROHIBITED",
            "GATE_PASSABLE_IF_NO_CLOSURE_INFORMATION",
            "ROAD_FACING_BUILDING_LOCATION_IS_ENTRANCE",
        ],
        "accepted_evidence_specification": None,
        "freshness_policy": None,
    },
    "baseline": {
        "profile": "N1_REFERENCE_ONLY",
        "preserve_existing_inputs_and_outputs": True,
        "threshold_rule": "round(total_min, 3) < 10",
        "candidate_selection": "NEAREST_REACHABLE",
        "target_connector": "OMITTED_WITH_OFFSET_DIAGNOSTIC",
    },
}


def get_config():
    """Return an independent JSON-compatible snapshot of current settings."""
    return deepcopy(CONFIG)


if __name__ == "__main__":
    print(json.dumps(get_config(), ensure_ascii=False, sort_keys=True,
                     indent=2, allow_nan=False))
