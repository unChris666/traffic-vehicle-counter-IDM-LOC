#!/usr/bin/env python3
"""Package the approved eight-video research run; never upload or run models.

The immutable PREPARE-v1 builder supplies extraction safety. This new wrapper
explicitly selects run_batch/v2 and carries the native geometry review evidence.
Unknown business facts remain null; this is not a final product result.
"""
from __future__ import annotations

import argparse
import ast
import base64
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

BASE_BUILDER = "docs/evidence/phase_8/verification/build_phase8_kaggle_bundle.py"
BASE_SHA256 = "157a03bbbab8f5aa1adddc654db6c08d604100db275186caaf0f60db897aac31"
MANIFEST = "docs/evidence/phase_8/config/batch_manifest_TGDI_G3_T1_v2.json"
KERNEL_ID = "chrisbiran/phase-8-tgdi-full-video-research"
OUTPUT_ROOT = "/kaggle/working/phase_8_tgdi_research"


def _sha(value):
    return hashlib.sha256(value).hexdigest()


def _base(repo):
    path = repo / BASE_BUILDER
    if _sha(path.read_bytes()) != BASE_SHA256:
        raise ValueError("Immutable PREPARE-v1 builder differs from retained source")
    spec = importlib.util.spec_from_file_location("phase8_immutable_v1_bundle_builder", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build(repo, output_dir):
    repo, output_dir = Path(repo).resolve(), Path(output_dir).resolve()
    base = _base(repo)
    manifest = json.loads((repo / MANIFEST).read_text())
    if (manifest.get("schema_version") != "phase8_batch_v1" or len(manifest.get("videos", [])) != 8
            or manifest.get("execution_purpose") != "RESEARCH_WITH_DECLARED_UNKNOWN_LOCATION"):
        raise ValueError("Expected the explicitly approved TGDI research manifest")
    files, payload, excluded = {}, {}, []

    def add(relative, expected=None):
        path = base._safe_relative(relative)
        if path.suffix not in {".py", ".json", ".ipynb", ".png"}:
            raise ValueError("Source/media type is not an allowed minimal research dependency")
        absolute = (repo / path).resolve()
        if not absolute.is_relative_to(repo) or not absolute.is_file():
            raise ValueError("Research dependency unavailable: " + relative)
        data = absolute.read_bytes()
        if expected is not None and _sha(data) != expected:
            raise ValueError("Research dependency SHA mismatch: " + relative)
        if path.suffix == ".py":
            ast.parse(data.decode(), filename=relative)
        files[relative] = {"sha256": _sha(data), "bytes": len(data)}
        payload[relative] = {**files[relative], "gzip_base64": base64.b64encode(gzip.compress(data, mtime=0)).decode("ascii")}
        return json.loads(data) if path.suffix == ".json" else None

    def reference(ref):
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) or not isinstance(ref.get("sha256"), str):
            raise ValueError("Explicit path/SHA research evidence reference required")
        return add(ref["path"], ref["sha256"])

    for path in base.SOURCE_PATHS:
        add(MANIFEST if path == base.MANIFEST else path)
    add(manifest["input_authorization_path"], manifest["input_authorization_sha256"])
    for key in ("location_metadata_review", "source_user_confirmation", "supersedes_input_configuration"):
        data = reference(manifest[key])
        if isinstance(data, dict) and "source_user_confirmation" in data:
            reference(data["source_user_confirmation"])
    for video in manifest["videos"]:
        geometry = add(video["geometry_path"], video["geometry_sha256"])
        if geometry.get("geometry_contract_accepted") is not True or geometry.get("counting_execution_allowed") is not True:
            raise ValueError("Per-video geometry is not accepted for this research run")
        reference(geometry["source_frame"])
        feedback = reference(geometry["approval_feedback"])
        for ref in feedback["evidence_frames"]:
            reference(ref)
        for document in (geometry, feedback):
            for key in ("source_proposal", "source_user_confirmation", "template_source"):
                if key in document:
                    reference(document[key])
        reference(video["source_inspection"])
        reference(video["geometry_proposal"])
        if "preview" in geometry:
            excluded.append({**geometry["preview"], "reason": "Optional overlay audit preview; native review PNG is bundled"})
    profile = json.loads((repo / base.PROFILE).read_text())
    for relative, expected in profile["source_bindings"].items():
        if files.get(relative, {}).get("sha256") != expected:
            raise ValueError("Frozen scientific control source changed: " + relative)
    binding = _sha(base.canonical(files).encode())
    bootstrap = base.make_bootstrap(payload, binding)
    substitutions = {
        "'source_files':_source_manifest, 'mode':'prepare'": "'source_files':_source_manifest, 'mode':'run_batch'",
        "MODE = 'prepare'": "MODE = 'run_batch'",
        "print('Mode:', MODE, '(input preparation and software guards; no model execution)')":
            "print('Mode:', MODE, '(approved full-video TGDI research; sequential CUDA0; business metadata incomplete)')",
    }
    for old, new in substitutions.items():
        if bootstrap.count(old) != 1:
            raise ValueError("PREPARE bootstrap wrapper shape changed")
        bootstrap = bootstrap.replace(old, new, 1)
    bootstrap += ("\nMANIFEST_PATH = REPO_ROOT / " + repr(MANIFEST)
                  + "\nPROFILE_PATH = REPO_ROOT / " + repr(base.PROFILE)
                  + "\nOUTPUT_ROOT = Path(" + repr(OUTPUT_ROOT) + ")"
                  + "\nprint('Research manifest:', MANIFEST_PATH)"
                  + "\nprint('Output:', OUTPUT_ROOT)\n")
    ast.parse(bootstrap)
    notebook = json.loads((repo / base.NOTEBOOK).read_text())
    for cell in notebook["cells"]:
        if cell["cell_type"] == "code":
            ast.parse(base._notebook_source(cell))
            cell["execution_count"], cell["outputs"] = None, []
    notebook["cells"] = [{"cell_type": "markdown", "id": "phase8-research-bundle-note", "metadata": {}, "source": [
        "# Phase 8 TGDI — approved full-video research run\n",
        "This source-bound wrapper selects `run_batch` with all eight user-approved geometries/directions.\n",
        "Raw detector/tracker/ReID/counting controls are unchanged; videos run sequentially on CUDA0.\n",
        "Store name, latitude and longitude remain explicitly unknown/null under the retained research acknowledgement.\n",
        "Outputs are accepted passage subtotals with pending/coverage limits, not complete production results or accuracy.\n",
    ]}, {"cell_type": "code", "id": "phase8-research-source-bootstrap", "metadata": {}, "execution_count": None,
         "outputs": [], "source": bootstrap.splitlines(keepends=True)}] + notebook["cells"]
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "phase8_tgdi_research.ipynb"
    path.write_text(json.dumps(notebook, indent=1, ensure_ascii=False) + "\n")
    metadata = {"id": KERNEL_ID, "title": "Phase 8 TGDI full-video research", "code_file": path.name,
        "language": "python", "kernel_type": "notebook", "is_private": True, "enable_gpu": True,
        "enable_tpu": False, "enable_internet": True, "machine_shape": "NvidiaTeslaT4",
        "dataset_sources": [base.DATASET], "kernel_sources": [], "competition_sources": [], "model_sources": [], "keywords": []}
    metadata_path = output_dir / "kernel-metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n")
    report = {"claim_type": "SOURCE_PACKAGING_NOT_MODEL_EXECUTION", "mode": "run_batch", "research_only": True,
        "business_metadata_complete": False, "source_bundle_binding_sha256": binding, "source_file_count": len(files), "source_files": files,
        "canonical_notebook_path": base.NOTEBOOK, "canonical_notebook_sha256": files[base.NOTEBOOK]["sha256"],
        "canonical_code_cells_modified": False, "bootstrap_parameter_overrides": {"MODE": "run_batch", "MANIFEST_PATH": MANIFEST, "OUTPUT_ROOT": OUTPUT_ROOT},
        "base_builder_sha256": BASE_SHA256, "builder_sha256": _sha(Path(__file__).read_bytes()),
        "submitted_notebook": {"path": str(path), "sha256": _sha(path.read_bytes()), "bytes": path.stat().st_size},
        "kernel_metadata": {"path": str(metadata_path), "sha256": _sha(metadata_path.read_bytes())},
        "external_optional_audit_previews": excluded, "videos_bundled": False, "model_weights_bundled": False,
        "actual_model_inference_executed": False, "upload_performed": False, "submission_folder": str(output_dir)}
    (output_dir / "source_bundle_manifest.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.repo, args.output_dir), indent=2, sort_keys=True))
