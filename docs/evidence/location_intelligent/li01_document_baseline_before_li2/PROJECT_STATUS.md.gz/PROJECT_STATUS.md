# Location Intelligent — status proyek terverifikasi

22 Oktober 2026. Scope terbaru: **LI-0 repaired PASS; LI-1 offline selection PASS**.
Reader, geometry validation, reference selection dan reject ledger dijalankan
hanya pada synthetic fixtures. Tidak ada full Area/accessibility/capacity,
routing/Recount/PPAC, query BigQuery, request data provider, download dataset
atau inference baru. Status lingkungan cloud hanya diperiksa untuk setup.

## Repository dan dasar bukti

Workspace `unChris666/traffic-vehicle-counter-IDM-LOC`, branch `work`, HEAD
`806ae761998e487265f3a032d616a59af56bb9a7`. `git status --short` memuat
perubahan pengguna `.gitignore`, `README.md`, `docs/PHASE_9_TASK.md` dan
banyak sumber/artifact untracked yang dipertahankan. Tidak ada pemeriksaan
GitHub remote pada tugas ini. Home/router/framework aplikasi terpadu belum
diimplementasikan pada repo ini; legacy di repo lain bukan runtime R1.

| Klaim terdahulu | Konfirmasi yang tersedia sekarang | Batas kesimpulan |
|---|---|---|
| 30 link/anchor checks pass,7 dokumen | Laporan QA lokal sebelumnya `/workspace/scratch/location-intelligent-documentation-qa.json`; ketujuh hash dokumen cocok sebelum revisi T2 | Bukti revisi dokumentasi sebelumnya, bukan jumlah link revisi sekarang; laporan scratch bukan artifact repo yang dijamin ada di clone baru |
| 4.080 historical files tetap konsisten | [Final verification B v8](../results/b_v8/verification/final_verification.json) mencatat4080; hash receipt cocok dengan retention manifest | Tidak mengulang scan4080 file pada tugas sekarang; memakai laporan tersimpan yang terikat checksum |
| B v7/B v8 dipertahankan | [Baseline retention malam](../results/nighttime_validation/verification/baseline_retention.json) terikat manifest; manifest hashes B v7/B v8 masih cocok | Catatan132/451 retained files dan11/15 live bindings adalah pemeriksaan historis, bukan inference baru |
| Runtime dan filter tidak berubah | Fingerprint sebelum tugas atas121 file runtime/config/receipt/source terpilih; filter user asli ikut dilindungi; pemeriksaan ulang pada QA tugas ini | Bukan klaim seluruh source di luar workspace diverifikasi; perubahan tugas ini terbatas dokumentasi+arsip brief |
| Night preview tervalidasi, counting malam belum | [Night verification](../results/nighttime_validation/verification/final_verification.json) terikat manifest, status PASS_WITH_EXPLICIT_E2E_BLOCKERS | Pixel/profile tests terdahulu tidak membuktikan nighttime counting reliable |

## Status workstream

| Workstream | Bukti aktual | Readiness/batas |
|---|---|---|
| Traffic Counter B v7/B v8 | [Selected run](../results/b_v8/selected_run.json): reviewed pilot TGDI-WEEKDAY-SIANG9128frame,74 accepted objek=73kendaraan+1pedestrian,67measured+7inferred,1pending,83invalid | Scoped reviewed pilot; bukan produksi otomatis. B v7 machine pembanding72accepted/24pending/86invalid tetap terpisah |
| Night input/Review-Filter | Retained Kaggle inspection10video/89.199frame; user memilih TKVQ-WEEKEND-MALAM, gamma0.65/exposure0.2/sharpness0.35/brightness0/shadows0 | Filter dipertahankan sebagai kandidat; geometri video ini dan actual model/counting smoke belum tervalidasi |
| Reference Area N1 | Arsip notebook23cell, query/code dan stored output contoh tersedia; tidak dieksekusi ulang | Summary1321/1304/5216 bukan proof full frozen spatial dataset. Export cell tidak punya output eksekusi |
| Source discovery | Dua identifier BigQuery, Overture buildings/places dan OSMnx operation terkonfirmasi secara statis | Live physical schema/permission/quota/pricing/freshness belum diverifikasi. RWI source UNKNOWN |
| Architecture/contracts | Envelope location_intelligent_v1 dan diagnostics/readiness kini implemented sesuai kontrak kanonis | Full geospatial/output contract masih rancangan; engine/business policy tetap mengikuti decision log |
| Validator offline LI-0 |49 tes PASS setelah6 regression fixes; baseline43 tes dipertahankan | Gate input lokal; READY bukan bukti isi geometry, actual coverage atau live integration |
| LI-1 local building selection |40 tes PASS;9record=5selected+4excluded. Invalid fixture=1selected+2excluded+6rejected/PARTIAL | Canonical GeoJSON synthetic, explicit CRS/metric transform, reconcilable ledger. Tidak ada real-snapshot validation |
| Full Area E2E/Recount | Arsitektur/reference rules terdokumentasi | Belum implemented/validated; needs real source acquisition dan keputusan unit/routing/universe/predicate/coverage |
| PPAC | Feature interface/gates terdokumentasi | Numerik BLOCKED: Excel/formula/constants/units/period/label/evaluation belum tersedia/disetujui; historical SPD unit UNKNOWN |

Diagram besar Location Intelligent dan brief bisnis Area–Recount–PPAC terpisah
belum tersedia, demikian pula workbook Excel. Tidak direkonstruksi sebagai
requirement atau formula. RWI tidak diasumsikan dari BigQuery/GEE/provider lain.

## Dasar dokumentasi yang sudah diselesaikan

Inventaris source beserta identifier/query/schema expectations, kontrak
raw→normalized→frozen→derived/reviewed/features, status multidimensi dan
roadmap offline/live diperjelas. Source adapters dibedakan dari downstream
PPAC feature adapters. Tahap dokumentasi sebelumnya bukan uji engine;
implementasi LI-0 terbaru dibatasi di bawah.

Peta otoritas dokumen:

- [Overview](LOCATION_INTELLIGENT_OVERVIEW.md): register sumber dan scope.
- [Architecture](AREA_COVERAGE_ARCHITECTURE.md): batas engine, alur dan persistence.
- [Inventory](DATA_SOURCE_INVENTORY.md): sumber terkonfirmasi dan UNKNOWN.
- [Canonical contract](AREA_COVERAGE_DATA_CONTRACT.md): fields/units/CRS/status/provenance.
- [Roadmap](IMPLEMENTATION_ROADMAP.md): urutan dan acceptance gates.
- [Decision log](AREA_COVERAGE_DECISIONS.md): keputusan terbuka dan dampak.
- [Reference specification](AREA_COVERAGE_SPEC.md), [test plan](AREA_COVERAGE_TEST_PLAN.md), [PPAC gates](PPAC_SPEC.md).

## Hasil eksekusi LI-0

**Historical21 Oktober2026, sebelum gap audit.** Python3.12.14,43 tes PASS;
source/fixture/documen baseline sekarang diarsipkan, bukan ditimpa sebagai
hasil baru. Perintah yang benar-benar dijalankan saat itu:

```bash
PYTHONDONTWRITEBYTECODE=1 python -B -m unittest discover \
  -s notebooks -p 'location_intelligent_validator_tests.py' -v

python -B notebooks/location_intelligent_validator.py \
  --context notebooks/fixtures/li0/context.json \
  --manifest notebooks/fixtures/li0/manifest.json \
  --root notebooks/fixtures/li0
```

- **43 tes,0failure,0error — PASS**; termasuk14 kasus fixture negatif/blocked,
  salah tipe nested, strict JSON, identity/config hashes, missing/empty/failed/
  unknown sources, quantity/unit/CRS, producer/artifact consistency,
  traversal/symlink, checksums dan dependency cycles.
- CLI fixture: **exit0, VALID, READY**,1 local source terverifikasi.
  `live_readiness=NOT_VERIFIED`; freshness/source vintage synthetic tetap
  UNKNOWN nonblocking. Source fixture bukan data Overture aktual.
- CLI diuji dalam child process dengan environment hanya
  PYTHONDONTWRITEBYTECODE, tanpa inherited credentials/PATH. Tes juga menolak
  socket/network dan write saat validator berjalan serta memeriksa import
  tidak menjalankan I/O/engine. Exit1 INVALID dan exit2 VALID/BLOCKED diuji.
- Bukan uji engine/building geometry atau replay Traffic. Tidak mengulang
  suite historis. Fingerprint121 existing protected files diperiksa untuk
  memastikan baseline/filter/runtime pengguna tetap utuh.

File implementasi: [validator](../notebooks/location_intelligent_validator.py),
[tests](../notebooks/location_intelligent_validator_tests.py),
[fixture context](../notebooks/fixtures/li0/context.json),
[manifest](../notebooks/fixtures/li0/manifest.json),
[invalid cases](../notebooks/fixtures/li0/invalid_cases.json), serta synthetic
building/empty GeoJSON di folder yang sama. Klarifikasi teknis ada pada
kontrak kanonis dan D25 decision log, tanpa schema tandingan.

**Historical LI-0 PASS** tidak menutup unit capacity, actual source schema/coverage,
freshness policy, global ID uniqueness, RWI/Excel atau keputusan PPAC.
Tidak ada known blocker untuk acceptance validator dalam scope ini.

## Hasil audit LI-0 dan eksekusi LI-1

Baseline43 tes dijalankan kembali dan lulus sebelum edit. Enam tes audit baru
direproduksi gagal pada source lama, lalu lulus setelah fix: unpaired Unicode
value/key, checksum PARTIAL, optional reason salah tipe, unused SRC04 yang
memblokir dan pembukaan FIFO. [Baseline v1](evidence/location_intelligent/li0_baseline_v1/manifest.json)
mempertahankan source/fixtures/documen asli sebelum perbaikan.

Command aktual setelah implementasi (Python3.13.5 sistem):

```bash
PROJ_NETWORK=OFF PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B -m unittest discover \
  -s notebooks -p 'location_intelligent_*tests.py' -v

PROJ_NETWORK=OFF /usr/bin/python3 -B notebooks/location_intelligent_buildings.py \
  --context notebooks/fixtures/li1/context.json \
  --manifest notebooks/fixtures/li1/manifest.json \
  --root notebooks/fixtures/li1 --source-ref fixture-buildings
```

**89 tes PASS,0failure,0error,0skip:**49 LI-0 termasuk43 baseline;40 LI-1.
GDAL/OGR3.10.3, GEOS3.13.1 dan PROJ lokal dipakai tanpa instalasi/network.
Shapely tidak tersedia; backend dan kesesuaian operasi N1 dijelaskan dalam
kontrak. Default Python3.12 tanpa GDAL hanya mendukung validator LI-0.

- [Fixture hasil bersih](evidence/location_intelligent/li01_20261022/li1_fixture_result.json):
  SUCCEEDED,9record=5selected+4selection exclusions+0quality rejections.
- [Fixture masalah](evidence/location_intelligent/li01_20261022/li1_invalid_fixture_result.json):
  PARTIAL,9record=1selected+2excluded+6rejected, semua row teraccount.
  Duplicate ID ditolak seluruh kemunculannya; tidak memilih first/last.
- JSON/GeoJSON canonical lokal `li_building_snapshot_v1` saja; source-level
  missing/failed/invalid berbeda dari valid empty/zero qualifying. Failure
  summary=null. Tidak ada CSV/Parquet/live adapter atau actual Overture run.
- Representative point WGS84 sebelum transformasi metric CRS context;
  full footprint area, distance≤radius, area>min dan standard area<max.
  Class/subtype precedence dan null-subtype fallback N1 dipertahankan.
- CLI LI-0/LI-1 diuji tanpa inherited credentials; PROJ_NETWORK=OFF pada
  geospatial tests. Input read-only, tidak ada OGR dataset Open/network atau
  Traffic inference. Geometri tidak direpair dan capacity tidak dihitung.

Hasil/log/commands tersimpan pada
[execution receipt](evidence/location_intelligent/li01_20261022/execution.json).
Perlindungan121 berkas runtime/baseline/filter lama diperiksa kembali pada
verification receipt task ini; tidak mengulang4080 historical-file audit.

**LI-0 PASS; LI-1 PASS untuk synthetic offline reference selection.** Real
building snapshot belum tersedia/tervalidasi. Actual source coverage/schema,
unit capacity, identity lintas ID/provider, routing/accessibility dan PPAC
tetap terbuka. Satu primary rejection per record tidak mengklaim semua isu
sekunder ditemukan. Parent manifest tidak diubah menjadi full-engine success.

File baru: [building helper](../notebooks/location_intelligent_buildings.py),
[tes LI-1](../notebooks/location_intelligent_buildings_tests.py), fixture folder
`notebooks/fixtures/li1/`; helper/tes LI-0 diperbaiki dan dokumen kanonis
diupdate. Tidak membuat framework baru.

## Tugas coding terkecil berikutnya

**LI-2 directed routing offline dengan graph fixture kecil**, parameter N1
eksplisit, serta tests one-way/no-path/parallel edges/coverage. Tidak fetch
OSM/Overture, tidak menghitung capacity final atau PPAC. LI-2 belum dimulai.
