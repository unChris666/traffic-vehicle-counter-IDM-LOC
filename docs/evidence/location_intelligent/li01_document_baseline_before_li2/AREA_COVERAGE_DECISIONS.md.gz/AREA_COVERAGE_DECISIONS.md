# Area Coverage — keputusan, konflik dan readiness

21 Oktober 2026. Register ini membedakan fakta sumber, rekomendasi dan approval.
Sumber R1/N1/T1/F1/B1/L1/L2 didefinisikan pada
[overview](LOCATION_INTELLIGENT_OVERVIEW.md#register-sumber). Semua keputusan
OPEN di bawah belum menjadi rule produksi. Dokumentasi tidak menutupnya
secara implisit.

## Keputusan scope yang sudah jelas

- **CONFIRMED:** pengguna meminta repo yang sama; tidak membuat/memigrasi repo.
- **REQUIREMENT T1/T2 (historical):** hanya analisis/dokumentasi, tidak mengubah runtime,
  Traffic Counter, night filters, Area Coverage/Recount/PPAC atau hasil lama.
- **REQUIREMENT LI-0 sekarang:** implementasikan validator offline beserta
  fixture/tes dan klarifikasi kontrak minimum; larangan mengubah runtime
  Traffic/filter/baseline dan larangan implementasi engine tetap berlaku.
- **FACT:** R1 belum mempunyai Home/router/framework aplikasi terpadu.
- **REQUIREMENT:** N1 adalah reference calculation; diagram dan business brief
  punya peran berbeda. F1/B1 belum ditemukan, bukan dianggap cocok dengan kode.

## Register keputusan terbuka

| ID | Bukti/konflik | Dampak | Rekomendasi, belum approval | Keputusan/bukti yang diperlukan |
|---|---|---|---|---|
| D01 | T1 menyebut existing Home; R1 baru notebook/HTML review. L1 Streamlit dan L2 Gradio berasal dari repo lain | Tidak ada router atau UI state existing yang bisa diasumsikan | Pertahankan helper/file contracts; jangan memilih framework atau port legacy otomatis | Owner memilih host UI saat tugas UI diotorisasi; F1 untuk navigasi |
| D02 | N1 CFG125m; docstring100m | Candidate akses dan hasil capacity bisa berbeda | Freeze125 sebagai reference parity, bukan approval125 untuk bisnis | Owner menetapkan max access distance dan dasar empiris; version control |
| D03 | N1 CFG10menit dan strict<; docstring7menit; rounded3decimal dipakai sebelum gate | Inclusion berbeda, termasuk near-boundary | Reproduce kode10 untuk parity; full-precision gate hanya varian perubahan terdokumentasi | Threshold, strictness dan rounding policy bisnis |
| D04 | Standard household4, apartment occupied units, dormitory occupied rooms, hotel guests terpisah | Legacy sum tidak punya unit homogen; PPAC dapat salah dimensi | Split metrics; keep legacy field, unknown tetap null | Definisi KK/dwelling/resident-equivalent, occupancy conversion, floor/rounding assumptions dan approval constants |
| D05 | N1 memilih nearest reachable access, bukan minimum total time; store snapped node tanpa final connector | Akses/ETA dapat berbeda dari interpretasi pengguna dan endpoint sebenarnya | Preserve directed graph; expose candidate costs/snap offsets/coverage; bandingkan selection alternatives terpisah | Mode selection, entrance/store connector, snap limit dan QA; tidak mengarang angka baru |
| D06 | Recount diminta menghitung building; N1 table hanya eligible residential/special | Recount bisa undercount universe tanpa diketahui | Tampilkan explicit universe; representative-point predicate sebagai kandidat konsisten N1, bukan keputusan final | All footprints/eligible/accessible, boundary inclusion, polygon predicate dan overlap capacity aggregation |
| D07 | Query bbox/radius terbatas; Recount polygon bebas | Polygon di luar snapshot tidak bisa dihitung lengkap | Coverage relation dan incomplete flags; union dedup berdasarkan source building key | Re-fetch extent/authorization vs covered-only result, coverage definition dan source freshness |
| D08 | Geometry exceptions dilewati; tidak ada explicit validity/type gate; UTM dipilih sebelum validasi | Silent exclusions dan CRS salah | Validate early; reject ledger; repair hanya explicit/versioned | Geometry repair policy, valid CRS/domain dan duplicate/source-ID handling |
| D09 | Release N1 dipin, graph live, dependency ranges/warnings; export cell20 tidak punya output | Reproducibility belum lengkap | Source/archive hashes, graph snapshot, environment lock, output manifest | Dataset/schema/access availability, snapshot/freshness policy, replay fixture dan export evidence |
| D10 | drive graph+constant7km/h+straight connector dianggap akses motor; fence/entrance tidak diperiksa | Tidak membuktikan perjalanan/legal accessibility fisik | Label model/access assumption; pertahankan OSM topology tanpa artificial turn | Mode network/legal access, private/service/bridge/tunnel policy dan verifikasi lapangan bila diperlukan |
| D11 | Delapan Traffic samples bukan24jam; source dates/durations/slot coverage dan weight belum diputuskan | Daily traffic feature tidak terdefinisi | Preserve sample-level category/direction/duration; no automatic day extrapolation | Daily normalization, weekday/weekend/holiday/time-period and category weights |
| D12 | Formula approved/Excel/constants tidak tersedia; label dashboard PPAC/Huff bukan SPD formula | Tidak bisa menghitung SPD yang bermakna | Return BLOCKED/null; bangun interface/lineage dulu | Formula bisnis, workbook/sheet/version/hash, constants units/owner/approval |
| D13 | BQ memiliki SPD/PERIODE tetapi bukan reference label/evaluation protocol yang diverifikasi | Klaim manfaat model atau pembanding belum sah | Validate label/period/store alignment dan predefined spatial/temporal split | Statistical model scope, quality of labels, metrics dan acceptance criteria |
| D14 | Counter mempunyai measured/estimated/pending/invalid, machine/reviewed; P1 reviewed bukan otomasi produksi | PPAC raw sum dapat double count atau memakai estimasi sebagai fakta | Pilih satu snapshot, pisahkan evidence levels dan completeness | Kebijakan fitur measured vs estimated/reviewed/missing; jangan mengubah engine untuk menyesuaikan SPD |
| D15 | F1 diagram dan B1 business brief terpisah belum tersedia | Tidak bisa memverifikasi full workflow/requirement correspondence | Gunakan hanya T1 untuk proposal halaman; tandai detail belum terkonfirmasi | Diagram dan brief resmi, lalu review delta terhadap dokumen ini |
| D16 | N1 unknown capacity fillna0; flags route/accessible bisa berbeda; export success dicatat setelah JSON ditulis | False completeness/zero demand atau manifest menyesatkan | Known subtotal+unknown counts, normalized statuses, atomic publication dan candidate audit | Versioned output contract dan golden parity vs corrected behavior tests |
| D17 | T1 menyebut retain filter F1YV; JSON aktual+konfirmasi pengguna sebelumnya mengikat TKVQ-WEEKEND | Risiko rename/apply recipe ke video salah | Tidak mengubah kedua source/konfigurasi; status filter TKVQ tetap kandidat, bukan production baseline | Tidak perlu tuning ulang untuk dokumen Area; F1YV recipe tidak diasumsikan ada |
| D18 | L1 memakai Google Open Buildings/Huff/EPSG3857; N1 memakai Overture/UTM/directed accessibility | Menggabungkan prototype dapat mengganti semantik tanpa keputusan | N1 tetap reference Area sesuai T1; L1 hanya referensi legacy | Approval eksplisit sebelum reuse provider, constants atau capacity model legacy |
| D19 | RWI tidak ditemukan pada source lokal/N1; tidak ada asset/table/API identifier | Tidak bisa mengambil, geo-join atau membentuk fitur RWI | Pertahankan UNKNOWN; tidak memilih Meta/GEE/BigQuery berdasarkan nama fitur | Provider resmi, identifier/schema/sample, unit/CRS/vintage/coverage, join dan usage policy |
| D20 | SRC02/SRC03 memberi query expectations, bukan live physical schema; query store tanpa SQL period/spatial bound | Risiko full scan, join berulang atau unit salah meski client dibuat sukses | Metadata-only verification dan bounded-query/cost design pada tugas live terpisah | Table/view type, types/nullability, partition/location, grain keys, auth/grants, quota/pricing/freshness |
| D21 | SPD historis di-cast string; unit asal tidak terbukti sama dengan target PPAC struk/hari | Label/model dapat salah dimensi | Simpan raw SPD dan unit UNKNOWN; jangan auto-alias menjadi target | Definisi bisnis SPD, satuan/periode dan mapping observed label yang disetujui |
| D22 | Source retrieval adapter berbeda dari PPAC feature adapter | E2E Area tidak dapat dibuktikan hanya dengan mock atau downstream feature joins | Overture buildings+OSM retrieval sebelum real Area E2E; BigQuery/POI optional per scope; feature adapters sesudah hasil valid | Scope dan live verification terpisah pada [roadmap](IMPLEMENTATION_ROADMAP.md); tidak ada implementasi otomatis |
| D23 | Offline snapshot, request failure, successful empty dan stale adalah keadaan berbeda | Satu flag sukses/0 dapat menyembunyikan input hilang atau context lama | Availability, quality, freshness dan module status terpisah menurut kontrak; no request=NOT_ATTEMPTED | Freshness/as-of policy, required source scope dan treatment partial; tidak mengarang TTL |
| D24 | Competitor BQ dan POI Overture berbeda namespace; cell16 meminjam client cell14 | Double count/dedup salah dan hidden dependency module opsional | Adapter client mandiri; source-tagged keys; tidak merge by name saja | Cross-source entity mapping, brand semantics, POI confidence/status dan dedup policy |

## Klarifikasi kontrak teknis untuk tugas berikutnya

Bagian envelope v1 di [kontrak kanonis](AREA_COVERAGE_DATA_CONTRACT.md)
menetapkan **usulan** input lokal, types, ID/hash/path safety dan perbedaan
validity/readiness untuk LI-0. Itu cukup spesifik untuk membatasi tugas
validator berikutnya; bukan keputusan bisnis D02–D14 atau bukti runtime.
Policy yang belum disuplai harus menghasilkan diagnostic/BLOCKED, bukan
diisi CFG N1 secara implisit. Source/diagram/Excel yang belum tersedia tidak
menghalangi tes schema offline, tetapi tetap menghalangi klaim E2E/bisnis.

### D25 — clarification LI-0 yang sudah diimplementasikan

**TECHNICAL DECISION dalam otorisasi tugas LI-0**, bukan approval bisnis:
gunakan helper standard-library pada `notebooks/`, pola unittest repo, tanpa
framework/dependency baru. Bentuk envelope `location_intelligent_v1`, quantity,
checksum/provenance/status dan readiness diuraikan pada
[kontrak kanonis](AREA_COVERAGE_DATA_CONTRACT.md#klarifikasi-serialization-li-0-v1-yang-diimplementasikan).
Ini melengkapi bentuk field yang sebelumnya baru semantik, bukan schema
yang bersaing. Source/artifact version tetap provenance external; payload
schema/geometry tidak diverifikasi oleh LI-0.

**Gate yang dipilih:** LI-1 building-selection input contract saja, bukan
capacity/routing atau live E2E. Hanya building snapshot dan tiga parameter
seleksi N1+metric CRS wajib; parameter tidak diisi dari default. Keputusan
bisnis/routing D02–D14 tidak ditutup untuk membuat fixture READY. Unknown
metadata toko/vintage/freshness yang tidak wajib tetap terlihat, sedangkan
required data unknown menghalangi gate. RWI/PPAC opsional yang belum siap
tidak memblokir input seleksi bangunan.

**Hasil:**43 tes fokus PASS, CLI fixture VALID/READY dengan live NOT_VERIFIED.
Rincian command/scope di [PROJECT_STATUS](PROJECT_STATUS.md#hasil-eksekusi-li-0).
No known blocker untuk acceptance LI-0; global uniqueness ID, physical schema,
payload quality, actual coverage, freshness policy dan semantik capacity
tetap membutuhkan tahap/policy berikutnya.

## Perbandingan sumber dan contoh impact

- **R1 vs T1:** input store/lat/lon/eight slots adalah requirement, bukan Home
  teruji. Unknown TGDI location tidak diganti lokasi contoh N1.
- **N1 kode vs komentar:** building berjarak110m dari eligible road dapat masuk
  candidate dengan CFG125, tetapi tidak dengan interpretasi100. Rute8menit
  dapat accessible dengan CFG10, tetapi tidak jika mengikuti komentar7.
  Ini contoh logika, bukan hasil lokasi yang baru dihitung.
- **N1 kapasitas vs kebutuhan bisnis:** satu rumah memberikan4 sedangkan satu
  occupied apartment unit memberikan1. Menamai sum sebagai KK atau penduduk
  tanpa konversi mencampur unit. Hotel tidak boleh ditambahkan otomatis.
- **N1 routing vs interpretasi lokasi:** output similar store mempunyai contoh
  Haversine sekitar29,9km tetapi road distance sekitar7,0km pada graph lokal.
  Helper nearest-node tidak membatasi snap offset; hasil tersebut memerlukan
  QA endpoint, bukan bukti toko sebenarnya hanya7km. Isu auxiliary store
  routing tidak otomatis membatalkan seluruh building table Area.
- **N1 vs Recount requirement T1:** menambahkan polygon yang melampaui query
  coverage atau menghitung commercial buildings dari filtered residential
  table tidak memenuhi complete-building-count requirement.
- **N1 output vs proof:** contoh1321/1304/5216 hanya satu stored run. Cell20
  tanpa executed output tidak membuktikan CSV/GeoJSON/result.json tersedia.
- **F1/B1:** belum bisa dibandingkan detailnya. Tidak ada approval formula
  SPD yang dapat diturunkan dari nama PPAC atau keberadaan historical SPD.

## Prioritas rekomendasi

**Pareto sebagai cara memprioritaskan, bukan statistik80/20 yang diukur:**
dahulukan tiga kelompok risiko: (1) unit/unknown capacity D04/D16,
(2) routing/access semantics D02/D03/D05/D10, (3) lineage/coverage D06/D07/D09.
Memperindah map tidak menyelesaikan ketiganya.

| Pilihan implementasi berikutnya | Strength | Weakness | Opportunity | Threat |
|---|---|---|---|---|
| **Validator/context+fixture offline — rekomendasi** | Kecil, independen engine, melindungi target/unit/provenance | Belum menghasilkan map atau angka bisnis | Dasar reusable untuk semua module dan partial failure | Jika constraint diabaikan setelahnya, integrasi tetap dapat mencampur context |
| Port notebook sekaligus ke UI | Cepat memperlihatkan demo perhitungan referensi | Globals, mixed capacity dan sumber live ikut terbawa | Visual review workflow lebih awal setelah policy jelas | Label hasil tampak final padahal semantic/coverage/export belum tervalidasi |

### D26 — LI-0 audit dan LI-1 local selection

22 Oktober 2026. **IMPLEMENTED dalam scope tugas:**6 regresi LI-0 direproduksi,
diperbaiki dan baseline sebelum fix diarsipkan;49 tes termasuk43 existing
regressions lulus. Contract dan readiness meaning dipertahankan.

LI-1 memakai canonical local GeoJSON, subclass dari BuildingRecord, SourceRef
CRS4326 dan metric CRS context. Ini bukan schema provider baru. Installed
OGR/GEOS/PROJ dipilih untuk backend offline karena Shapely tidak tersedia;
provider dan aturan N1 tidak diganti. Seluruh duplicate ID ditolak dengan
PARTIAL snapshot; tidak dedup by first. Ordinary UTM domain gate dan no
geometry repair dipertahankan. Detail pada
[kontrak LI-1](AREA_COVERAGE_DATA_CONTRACT.md#perbaikan-li-0-dan-kontrak-li-1-offline--22-oktober-2026).

**RESULT:**40 tes LI-1+49 tes LI-0 lulus; hanya synthetic fixtures. Belum
real N1/Overture snapshot parity. D04 capacity, routing/accessibility,
Recount, physical source schema/coverage dan PPAC tetap terbuka. ID berbeda
dengan footprint identik belum diputuskan menjadi satu bangunan fisik;
tidak membuat spatial/entity merge pada task ini.

**Next smallest task setelah LI-1 PASS terbatas:** LI-2 directed routing
dengan graph fixture offline dan parameter referensi eksplisit, tanpa source
fetch, capacity final atau UI. Ikuti
[roadmap otoritatif](IMPLEMENTATION_ROADMAP.md). Full Area/Recount UI masih
DOCUMENTED dengan blockers di atas; PPAC numerik **BLOCKED**. LI-1 tidak
menjalankan LI-2 otomatis.
