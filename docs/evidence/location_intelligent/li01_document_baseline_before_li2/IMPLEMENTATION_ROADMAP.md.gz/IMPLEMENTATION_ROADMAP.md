# Location Intelligent — roadmap implementasi

22 Oktober 2026. LI-0 repaired dan LI-1 selection telah **PASS** untuk gate
offline terbatas; tahap berikutnya
tetap **PROPOSAL**, bukan perubahan urutan fase
Traffic Counter0–13. Label LI di sini hanya dependensi integrasi lokasi.
[Arsitektur](AREA_COVERAGE_ARCHITECTURE.md),
[kontrak](AREA_COVERAGE_DATA_CONTRACT.md),
[inventaris](DATA_SOURCE_INVENTORY.md) dan
[keputusan terbuka](AREA_COVERAGE_DECISIONS.md) tetap otoritas masing-masing.

## Evaluasi urutan kerja

Urutan offline validator → frozen reference calculations → routing → live
source/map/export → Recount → feature adapters → PPAC masuk akal dengan
penjelasan penting: **source retrieval adapters mendahului validasi Area
end-to-end dengan data nyata**, berbeda dari feature adapters downstream.
Pembacaan snapshot dan ekspor dapat diuji offline lebih awal; map basemap
live bukan syarat kalkulasi. Mock/fixture sukses tidak membuktikan akses layanan.

## Tahap, input, proses dan gate

| Tahap | Input | Proses/output yang direncanakan | Gate sebelum tahap berikutnya |
|---|---|---|---|
| **LI-0 — repaired validator, PASS gate terbatas** | JSON context/config/manifest lokal dengan schema v1, fixture valid/invalid, optional artifact lokal | Types/ranges/IDs/hash/references/status, validity dan gate input seleksi bangunan LI-1 |49 tes PASS termasuk43 baseline+6 repaired regressions; READY bukan bukti payload/live integration |
| **LI-1 — reader dan building selection, PASS offline** | Canonical local GeoJSON li_building_snapshot_v1 dan SourceRef/config; synthetic diberi label | Read-only reader, payload/geometry validation, N1 selection, reject ledger/reconciliation |40 tes PASS;9record=5selected+4excluded. Invalid sample=1selected+2excluded+6rejected/PARTIAL. Capacity sengaja belum implemented; real N1 snapshot belum tersedia |
| **LI-2 — routing offline** | Directed multigraph fixture, buildings, target, explicit routing config | Candidate selection, one-way/no-path, connector costs, snap/coverage diagnostics dan deterministic routes | Tests boundary/rounding/parallel edges/disconnected graph/out-of-coverage; decisions D02/D03/D05/D10 tercatat sebagai reference parity atau approved policy, bukan dipilih diam-diam |
| **LI-3 — source retrieval integration** | SRC04 buildings/SRC05 graph identifiers, explicit request scope, auth refs bila diperlukan, provider policy; SRC02/03/08 optional | Implement adapters terpisah, mock response/error/schema tests; kemudian minimal live metadata/schema/permission/cost checks hanya pada tugas live terpisah; freeze acquired inputs | Core Area perlu sumber buildings+graph kompatibel dan terverifikasi. BigQuery schema/grain/partition/cost belum confirmed; RWI blocked sampai mapping. Tidak menjalankan query store legacy tanpa bound karena contoh N1 melakukannya |
| **LI-4 — Area end-to-end, persistence/map/export** | Acquired/frozen real source package dari LI-3, validated target/config, calculation/routing policies | Bounded real run, candidate/reject diagnostics, atomic manifest, CSV/GeoJSON/JSON; map adalah derived view | Reopen tanpa re-fetch memberi hasil sama; scope/units/completeness jelas; output success setelah semua wajib finalized. Real source parity dan kualitas hasil dinilai terpisah dari pass fixture |
| **LI-5 — Recount** | Validated Area/source snapshot, polygon revision, approved universe/predicate/boundary/coverage policy | Membership per building, per-polygon subtotal, union unique keys dan completeness | D06/D07 selesai untuk scope implementasi; polygon outside snapshot tidak dianggap count lengkap; tidak menjalankan model Traffic/routing ulang saat edit polygon |
| **LI-6 — downstream feature adapters** | Selected Area/Recount dan Traffic result manifests yang sudah valid, mapping target/period/units, pilihan machine atau reviewed | Read-only feature records + source refs; flags measured/estimated/missing dan coverage | Tidak sum machine+reviewed; tidak extrapolate delapan klip ke24jam tanpa kebijakan; same-target/period gate terpenuhi; old events tidak dimodifikasi |
| **LI-7 — PPAC** | LI-6 features, approved formula/constants/units, Excel baseline version/hash dan evaluation protocol | Versioned PPAC input/output breakdown; comparison yang dapat direproduksi | D04/D11–D14 teratasi sesuai scope; historical SPD unit/label alignment confirmed; tidak menerbitkan angka SPD saat formula/input wajib BLOCKED |

Host UI D01 diputuskan sebelum implementasi Home/navigation; tidak perlu
memilih framework untuk LI-0–LI-3. Requirement framework tidak disimpulkan
dari legacy Streamlit/Gradio. Tidak menambah layanan terdistribusi.

## Batas offline dan live

- **Offline yang realistis:** schema/context/hash/file checks, synthetic
  building/graph tests, deterministic calculations, exports, Recount geometry
  fixtures dan feature joins. Fixture tidak membuktikan source freshness,
  credential permission, building completeness atau keberhasilan provider.
- **Offline dengan snapshot nyata:** replay deterministik dimungkinkan bila
  snapshot lengkap, hash/coverage/schema valid dan lisensi/mode pemakaian
  jelas. Full frozen building/graph N1 belum terbukti tersedia di workspace.
- **Memerlukan live access terpisah:** metadata physical schema/partition BQ,
  permission/billing/estimated scan, Overture release/schema availability,
  acquisition graph dan quota/freshness provider. Tidak ada pemeriksaan ini
  pada tugas dokumentasi sekarang.
- **Membutuhkan keputusan bisnis/bukti:** unit capacity, accessibility
  thresholds/selection, Recount universe, traffic daily normalization, RWI
  source, formula PPAC dan baseline Excel. Pass validator tidak menutupnya.

## Instruksi tepat untuk tugas coding berikutnya

LI-0 repaired dan LI-1 selesai melalui
[validator](../notebooks/location_intelligent_validator.py),
[building helper](../notebooks/location_intelligent_buildings.py), tes dan fixture lokal.
Hasil/command dan batas acceptance ada di
[PROJECT_STATUS](PROJECT_STATUS.md#hasil-audit-li-0-dan-eksekusi-li-1).

**Tugas terkecil berikutnya: LI-2 directed routing offline** dengan graph
fixture kecil, target/access/candidate diagnostics, one-way/no-path/parallel
edges/coverage tests dan parameter N1 eksplisit. Source retrieval, capacity
final, UI dan PPAC tetap tahap lain. Pass LI-1 fixture bukan real integration
atau bukti akses fisik. Tidak memulai LI-2 otomatis.
